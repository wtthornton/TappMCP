// smart.begin tool stub
